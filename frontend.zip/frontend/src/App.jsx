
import { useState } from 'react'
import {
  Flame, LayoutDashboard, Map, ChartNoAxesCombined,
  ShieldAlert, Info, Search, Bell, Menu, X,
  Activity, Radio, ArrowUpRight, Clock3, MapPin,
  Layers, Filter
} from 'lucide-react'

import {
  MapContainer, TileLayer, CircleMarker, Popup
} from 'react-leaflet'

import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, BarChart, Bar, CartesianGrid
} from 'recharts'

import 'leaflet/dist/leaflet.css'
import './App.css'

const fireData = [
  { id: 1, name: 'Detection 001', lat: 30.3165, lng: 78.0322, frp: 12.4, confidence: 'nominal', location: 'Dehradun' },
  { id: 2, name: 'Detection 002', lat: 31.1048, lng: 77.1734, frp: 28.6, confidence: 'high', location: 'Shimla' },
  { id: 3, name: 'Detection 003', lat: 29.9457, lng: 78.1642, frp: 5.2, confidence: 'low', location: 'Haridwar' },
  { id: 4, name: 'Detection 004', lat: 30.9010, lng: 77.0967, frp: 42.8, confidence: 'high', location: 'Solan' },
  { id: 5, name: 'Detection 005', lat: 32.2190, lng: 77.1887, frp: 8.7, confidence: 'nominal', location: 'Manali' },
  { id: 6, name: 'Detection 006', lat: 29.3803, lng: 79.4636, frp: 17.3, confidence: 'nominal', location: 'Nainital' },
]

const trendData = [
  { date: 'Oct 26', detections: 420 },
  { date: 'Oct 27', detections: 510 },
  { date: 'Oct 28', detections: 390 },
  { date: 'Oct 29', detections: 650 },
  { date: 'Oct 30', detections: 580 },
  { date: 'Oct 31', detections: 720 },
  { date: 'Nov 01', detections: 610 },
]

const confidenceData = [
  { name: 'Nominal', count: 6035 },
  { name: 'Low', count: 1027 },
  { name: 'High', count: 65 },
]

const navigation = [
  { name: 'Overview', icon: LayoutDashboard },
  { name: 'Fire Map', icon: Map },
  { name: 'Analytics', icon: ChartNoAxesCombined },
  { name: 'Risk Intelligence', icon: ShieldAlert },
  { name: 'Methodology', icon: Info },
]

function StatCard({ icon: Icon, label, value, detail }) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <div className="stat-icon"><Icon size={19} /></div>
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-detail">{detail}</div>
    </div>
  )
}

function FireMap({ compact = false }) {
  return (
    <div className={`map-wrapper ${compact ? 'map-compact' : ''}`}>
      <MapContainer
        center={[30.7, 78.0]}
        zoom={compact ? 6 : 7}
        scrollWheelZoom={true}
        className="leaflet-map"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {fireData.map((fire) => (
          <CircleMarker
            key={fire.id}
            center={[fire.lat, fire.lng]}
            radius={Math.max(7, Math.min(16, fire.frp / 3))}
            pathOptions={{
              color: fire.confidence === 'high' ? '#ff5b35' : '#f5a623',
              fillColor: fire.confidence === 'high' ? '#ff5b35' : '#f5a623',
              fillOpacity: 0.75,
              weight: 2,
            }}
          >
            <Popup>
              <strong>{fire.name}</strong><br />
              Location: {fire.location}<br />
              FRP: {fire.frp} MW<br />
              Confidence: {fire.confidence}
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
      <div className="map-legend">
        <span><i className="legend-dot high" /> High confidence</span>
        <span><i className="legend-dot nominal" /> Other detections</span>
      </div>
    </div>
  )
}

function Overview() {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">INTELLIGENCE CENTER / OVERVIEW</div>
          <h1>Fire Intelligence Overview</h1>
          <p>Monitor satellite fire detections and geographical activity.</p>
        </div>
        <div className="updated-label"><Radio size={15} /> Dataset loaded</div>
      </div>

      <div className="stats-grid">
        <StatCard icon={Flame} label="Fire detections" value="7,127" detail="NASA FIRMS dataset" />
        <StatCard icon={ShieldAlert} label="High confidence" value="65" detail="Satellite confidence class" />
        <StatCard icon={Activity} label="Average FRP" value="4.29 MW" detail="Fire radiative power" />
        <StatCard icon={MapPin} label="Geographical coverage" value="India" detail="Dataset region to be verified" />
      </div>

      <div className="content-grid">
        <section className="panel map-panel">
          <div className="panel-heading">
            <div>
              <div className="panel-title">Geospatial Fire Activity</div>
              <div className="panel-subtitle">Illustrative fire markers · OpenStreetMap</div>
            </div>
            <span className="live-tag"><span /> MAP</span>
          </div>
          <FireMap compact />
        </section>

        <section className="panel activity-panel">
          <div className="panel-heading">
            <div>
              <div className="panel-title">Detection Activity</div>
              <div className="panel-subtitle">Illustrative daily trend</div>
            </div>
            <Activity size={18} className="muted-icon" />
          </div>
          <div className="chart-area">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="fireGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ff7043" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#ff7043" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#272b35" strokeDasharray="3 3" />
                <XAxis dataKey="date" stroke="#777f8e" tick={{ fontSize: 10 }} />
                <YAxis stroke="#777f8e" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ background: '#171b24', border: '1px solid #303541', borderRadius: 8 }} />
                <Area type="monotone" dataKey="detections" stroke="#ff7043" fill="url(#fireGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>
      </div>

      <div className="content-grid bottom-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <div className="panel-title">Confidence Distribution</div>
              <div className="panel-subtitle">NASA FIRMS dataset · 7,127 records</div>
            </div>
          </div>
          <div className="chart-area short-chart">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={confidenceData} layout="vertical">
                <CartesianGrid stroke="#272b35" strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" stroke="#777f8e" tick={{ fontSize: 10 }} />
                <YAxis type="category" dataKey="name" stroke="#777f8e" tick={{ fontSize: 11 }} width={65} />
                <Tooltip contentStyle={{ background: '#171b24', border: '1px solid #303541', borderRadius: 8 }} />
                <Bar dataKey="count" fill="#ed784c" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="panel insight-panel">
          <div className="panel-heading">
            <div>
              <div className="panel-title">Intelligence Notes</div>
              <div className="panel-subtitle">Initial dataset observations</div>
            </div>
          </div>
          <div className="insight">
            <div className="insight-icon"><Activity size={17} /></div>
            <div><strong>Confidence analysis</strong><p>Most records are classified as nominal confidence.</p></div>
          </div>
          <div className="insight">
            <div className="insight-icon"><Flame size={17} /></div>
            <div><strong>FRP distribution</strong><p>Average FRP is 4.29 MW. Individual detections vary significantly.</p></div>
          </div>
          <div className="insight">
            <div className="insight-icon"><MapPin size={17} /></div>
            <div><strong>Geospatial analysis</strong><p>OSM context enrichment is the next development milestone.</p></div>
          </div>
        </section>
      </div>
    </>
  )
}

function FireMapPage() {
  const [filter, setFilter] = useState('all')

  const filtered = fireData.filter(fire =>
    filter === 'all' || fire.confidence === filter
  )

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">INTELLIGENCE CENTER / GEOSPATIAL</div>
          <h1>Fire Detection Map</h1>
          <p>Explore satellite detections in their geographical context.</p>
        </div>
        <div className="updated-label"><Radio size={15} /> Interactive map</div>
      </div>

      <div className="map-controls">
        <div><Layers size={17} /> OpenStreetMap base layer</div>
        <label><Filter size={16} />
          <select value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="all">All confidence levels</option>
            <option value="high">High confidence</option>
            <option value="nominal">Nominal confidence</option>
            <option value="low">Low confidence</option>
          </select>
        </label>
      </div>

      <section className="panel full-map-panel">
        <FireMap />
      </section>

      <section className="panel detection-list">
        <div className="panel-heading">
          <div>
            <div className="panel-title">Mapped detections</div>
            <div className="panel-subtitle">{filtered.length} illustrative records displayed</div>
          </div>
        </div>
        {filtered.map(fire => (
          <div className="detection-row" key={fire.id}>
            <div className="detection-marker"><Flame size={17} /></div>
            <div className="detection-info"><strong>{fire.location}</strong><span>{fire.name} · {fire.confidence} confidence</span></div>
            <div className="detection-frp">{fire.frp} MW</div>
          </div>
        ))}
      </section>
    </>
  )
}

function Analytics() {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">INTELLIGENCE CENTER / ANALYTICS</div>
          <h1>Fire Analytics</h1>
          <p>Explore fire detection patterns and satellite measurements.</p>
        </div>
      </div>
      <div className="stats-grid">
        <StatCard icon={Flame} label="Total records" value="7,127" detail="Loaded CSV records" />
        <StatCard icon={Activity} label="Mean FRP" value="4.29 MW" detail="Dataset average" />
        <StatCard icon={Clock3} label="Time dimension" value="14" detail="Dataset columns" />
        <StatCard icon={ShieldAlert} label="High confidence" value="65" detail="High confidence records" />
      </div>
      <section className="panel analytics-panel">
        <div className="panel-heading"><div><div className="panel-title">Confidence Distribution</div><div className="panel-subtitle">Detection counts by confidence class</div></div></div>
        <div className="chart-area large-chart">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={confidenceData}>
              <CartesianGrid stroke="#272b35" strokeDasharray="3 3" />
              <XAxis dataKey="name" stroke="#777f8e" />
              <YAxis stroke="#777f8e" />
              <Tooltip contentStyle={{ background: '#171b24', border: '1px solid #303541', borderRadius: 8 }} />
              <Bar dataKey="count" fill="#ed784c" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="panel analytics-panel">
        <div className="panel-heading"><div><div className="panel-title">Detection trend preview</div><div className="panel-subtitle">Illustrative data — replace with actual date aggregation</div></div></div>
        <div className="chart-area large-chart">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <CartesianGrid stroke="#272b35" strokeDasharray="3 3" />
              <XAxis dataKey="date" stroke="#777f8e" />
              <YAxis stroke="#777f8e" />
              <Tooltip contentStyle={{ background: '#171b24', border: '1px solid #303541', borderRadius: 8 }} />
              <Area type="monotone" dataKey="detections" stroke="#ff7043" fill="#ff7043" fillOpacity={0.15} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>
    </>
  )
}

function InformationPage({ page }) {
  const content = page === 'Risk Intelligence'
    ? {
        eyebrow: 'INTELLIGENCE CENTER / RISK',
        title: 'Risk Intelligence',
        description: 'A framework for assessing fire intensity and geographical exposure.',
        items: [
          ['Severity scoring', 'FRP-based fire intensity indicators.'],
          ['Geographical exposure', 'Distance to forests, settlements, roads and water bodies.'],
          ['Temporal patterns', 'Repeated detections and changes in fire activity.'],
          ['Confidence assessment', 'Satellite detection confidence and observation limitations.'],
        ],
      }
    : {
        eyebrow: 'INTELLIGENCE CENTER / METHODOLOGY',
        title: 'Data & Methodology',
        description: 'Understand the sources and methods behind FlareX.',
        items: [
          ['NASA FIRMS', 'Satellite active-fire and thermal anomaly observations.'],
          ['OpenStreetMap', 'Geographical context such as roads, forests and settlements.'],
          ['Temporal analysis', 'Date and acquisition-time patterns in fire observations.'],
          ['Risk methodology', 'A transparent, explainable framework under development.'],
        ],
      }

  return (
    <>
      <div className="page-heading">
        <div><div className="eyebrow">{content.eyebrow}</div><h1>{content.title}</h1><p>{content.description}</p></div>
      </div>
      <div className="info-grid">
        {content.items.map(([title, description], i) => (
          <div className="panel info-card" key={title}>
            <div className="info-number">0{i + 1}</div>
            <h3>{title}</h3>
            <p>{description}</p>
            <span className="development-label">IN DEVELOPMENT</span>
          </div>
        ))}
      </div>
      <div className="notice"><Info size={18} /><p>FlareX is a research and engineering prototype. It does not provide emergency alerts or verified fire-ground intelligence.</p></div>
    </>
  )
}

function App() {
  const [activePage, setActivePage] = useState('Overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [search, setSearch] = useState('')

  const renderPage = () => {
    if (activePage === 'Overview') return <Overview />
    if (activePage === 'Fire Map') return <FireMapPage />
    if (activePage === 'Analytics') return <Analytics />
    return <InformationPage page={activePage} />
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-icon"><Flame size={23} fill="currentColor" /></div>
          <div><strong>FLARE<span>X</span></strong><small>GEOSPATIAL INTELLIGENCE</small></div>
          <button className="mobile-close" onClick={() => setSidebarOpen(false)}><X /></button>
        </div>

        <div className="sidebar-section-label">WORKSPACE</div>
        <nav className="nav-list">
          {navigation.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={`nav-item ${activePage === name ? 'active' : ''}`}
              onClick={() => { setActivePage(name); setSidebarOpen(false) }}
            >
              <Icon size={18} />
              <span>{name}</span>
              {name === 'Risk Intelligence' && <span className="nav-soon">NEW</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="system-status"><span className="status-dot" /><div><strong>Development mode</strong><small>Prototype environment</small></div></div>
          <div className="sidebar-version">FLAREX · VERSION 0.1.0</div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setSidebarOpen(true)}><Menu /></button>
          <div className="breadcrumb">Workspace <span>/</span> <strong>{activePage}</strong></div>
          <div className="topbar-actions">
            <div className="search-box"><Search size={16} /><input placeholder="Search detections..." value={search} onChange={e => setSearch(e.target.value)} /></div>
            <button className="icon-button" title="Notifications"><Bell size={18} /></button>
            <div className="avatar">FX</div>
          </div>
        </header>

        <div className="page-content">
          {renderPage()}
          <footer className="footer">
            <span>FLAREX © 2026</span>
            <span>Satellite fire intelligence · Research prototype</span>
            <span>NASA FIRMS + OpenStreetMap</span>
          </footer>
        </div>
      </main>

      {sidebarOpen && <button className="sidebar-overlay" onClick={() => setSidebarOpen(false)} aria-label="Close navigation" />}
    </div>
  )
}

export default App
